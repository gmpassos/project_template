## 1.0.0

- `___project_name_dir___`: Initial version.
- Created by `project_template`.
